The runable files are the following:
	markowitz_portfolio.m	baseline_rebalancing.m	baseline_withoutrebalancing.m
	matlabcode0.m	matlabcode1.m	matlabcode2.m	matlabcode3.m

Other runable files are:
	cvx_markowitz1_2.m			supportive function for Markowitz portfolio construction
	RSIcal.py				calculating RSI for stocks
	code.ipynb			 	condense all css file in Files folder to one cvs file

CSV TABLES:
	output.csv				ending prices of all stocks from 2010-2020	output2015-2020.csv			pre-processed stock prices from 2010-2015	output2010-2015.csv			pre-processed stock prices from 2015-2020	rf2517.csv				risk-free rate preprocessed file	stock_RSI_without_date.csv		stock RSI preprocessed file	weekly_spdr_rates.xlsx			risk-free rate raw file
	